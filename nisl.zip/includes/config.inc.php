<?php
/*
 * Subrion Open Source CMS 4.0.5
 * Config file generated on 10 September 2016 06:32:19
 */

define('INTELLI_CONNECT', 'mysqli');
define('INTELLI_DBHOST', 'localhost');
define('INTELLI_DBUSER', 'root');
define('INTELLI_DBPASS', '');
define('INTELLI_DBNAME', 'nisl');
define('INTELLI_DBPORT', '3306');
define('INTELLI_DBPREFIX', 'sbr405_');

define('IA_SALT', '#401C820204');

// debug mode: 0 - disabled, 1 - enabled
define('INTELLI_DEBUG', 0);

